const cds = require('@sap/cds');

// Delegate bootstrapping to built-in server.js of CDS
module.exports = cds.server