const cds = require('@sap/cds')

// https://cap.cloud.sap/docs/guides/providing-services#registering-event-handlers
module.exports = async function () {
    this.on('CREATE', `Products`, async (req, next) => {
        const { Name } = req.data;

        try {
            // Check if a product with the same name already exists
            const existingProducts = await cds.transaction(req).run(
                SELECT.from('sap_ui5_marketplace_Products').where({ Name })
            );

            if (existingProducts.length > 0) {
                const error = new Error(`Product with name "${Name}" already exists.`);
                error.status = 409; // Conflict
                throw error;
            }

            console.log('Creating Product:', req.data);
            return next();
        } catch (error) {
            console.error(error);
            if (!error.status) {
                error.status = 500; // Internal Server Error
            }

            return next(req.reject(error.status, error.message));
        }
    });


    this.on('UPDATE', 'Products', async (req, next) => {
        const { Name, ID } = req.data;

        try {
            const existingProducts = await cds.transaction(req).run(
                SELECT.from('sap_ui5_marketplace_Products').where({ Name, ID: { '!=': ID } })
            );

            if (existingProducts.length > 0) {
                const error = new Error(`Product with name "${Name}" already exists.`);
                error.status = 409;
                throw error;
            }

            console.log('Updating Product:', req.data);
            return next();
        } catch (error) {
            console.error(error);
            if (!error.status) {
                error.status = 500;
            }
            return next(req.reject(error.status, error.message));
        }
    });


    // this.after(['CREATE', 'UPDATE', 'DELETE'], 'Products', (req) => {
    //     console.log(req)
    //     return req
    // })




}
