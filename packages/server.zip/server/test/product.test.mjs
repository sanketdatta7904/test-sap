import { expect } from 'chai';
import request from 'supertest';
import express from 'express';
import cds from '@sap/cds';
import sqlite3 from 'sqlite3';

const app = express();
await cds.connect.to('db');
await cds.serve('all').in(app);

describe('Products Service', () => {
    let server;

    before(async () => {
        server = app.listen(4004);
        // Mock database setup
        const sql = `
        CREATE TABLE sap_ui5_marketplace_Products (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL
        );
        INSERT INTO sap_ui5_marketplace_Products (Name) VALUES ('Existing Product');
        `;
        const database = new sqlite3.Database(':memory:');
        database.exec(sql, (err) => {
            if (err) {
                console.error(err);
            }
        });
    });

    after(() => {
        server.close();
    });

    describe('CREATE Product', () => {
        it('should create a new product', async () => {
            const res = await request(server)
                .post('/Products')
                .send({ Name: 'New Product' });
            expect(res.status).to.equal(201);
        });

        it('should not create a product with an existing name', async () => {
            const res = await request(server)
                .post('/Products')
                .send({ Name: 'Existing Product' });
            expect(res.status).to.equal(409);
            expect(res.body.error.message).to.equal('Product with name "Existing Product" already exists.');
        });
    });

    describe('UPDATE Product', () => {
        it('should update an existing product', async () => {
            const res = await request(server)
                .patch('/Products(1)')
                .send({ Name: 'Updated Product' });
            expect(res.status).to.equal(200);
        });

        it('should not update to a product with an existing name', async () => {
            await request(server)
                .post('/Products')
                .send({ Name: 'Another Product' });

            const res = await request(server)
                .patch('/Products(2)')
                .send({ Name: 'Existing Product' });
            expect(res.status).to.equal(409);
            expect(res.body.error.message).to.equal('Product with name "Existing Product" already exists.');
        });
    });
});
